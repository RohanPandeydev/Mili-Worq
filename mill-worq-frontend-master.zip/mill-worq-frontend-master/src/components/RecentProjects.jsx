import React from "react";

const RecentProjects = () => {
    return (
        <ul className="dashboard-project-list">
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
            <li>
                <a href="#" className="dashboard-project-des link">
                    <span>230067</span>
                    <h4>Audubon Square Apartments</h4>
                    <ul className="date-list">
                        <li>
                            <i className="fa-solid fa-calendar" />
                            Dec 28
                        </li>
                        <li>
                            <i className="fa-solid fa-clock" />
                            11:30 AM
                        </li>
                    </ul>
                </a>
            </li>
        </ul>
    );
};

export default RecentProjects;
