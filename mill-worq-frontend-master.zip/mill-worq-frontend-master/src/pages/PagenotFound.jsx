import React from 'react'

const PagenotFound = () => {
  return (
    <p className=''>PagenotFound</p>
  )
}

export default PagenotFound